package trabajadores;


import java.util.ArrayList;
//MANDAR A ANTON
public class Director extends Trabajador{
	
	public Director(String nombre, String apellido, int edad, double sueldo) {
		super(nombre, apellido, edad, sueldo);
		
	}
}