package enums;

public enum Idioma {ENGLISH,SPANISH,FRANCE,GERMAN,PORTUGUESE}
